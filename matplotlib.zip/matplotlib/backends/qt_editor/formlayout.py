from .. import cbook
from ._formlayout import *


cbook.warn_deprecated(
    "3.1", name=__name__, obj_type="module",
    alternative="the formlayout module available on PyPI")
